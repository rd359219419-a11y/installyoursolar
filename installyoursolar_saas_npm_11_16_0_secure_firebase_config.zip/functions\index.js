const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
admin.initializeApp();
const stripeSecretKey = defineSecret("STRIPE_SECRET_KEY");

exports.createCheckout = onRequest({ secrets: [stripeSecretKey] }, async (req, res) => {
  try {
    if (req.method !== "POST") return res.status(405).send("Method Not Allowed");
    const amount = Number(req.body?.amount || 50000);
    if (!Number.isInteger(amount) || amount < 100 || amount > 1000000) {
      return res.status(400).json({ error: "Amount must be an integer between 100 and 1000000 cents." });
    }
    const stripe = require("stripe")(stripeSecretKey.value());
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [{ price_data: { currency: "nzd", product_data: { name: "InstallYourSolar.com Solar Installation Deposit" }, unit_amount: amount }, quantity: 1 }],
      mode: "payment",
      success_url: "https://installyoursolar.com/success",
      cancel_url: "https://installyoursolar.com/cancel"
    });
    res.json({ url: session.url });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});
