#!/bin/bash
set -e
echo "Building InstallYourSolar.com..."
cd web
npx -y npm@11.16.0 run build
cd ..
echo "Deploying to Firebase..."
firebase deploy
