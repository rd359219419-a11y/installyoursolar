@echo off
echo Building InstallYourSolar.com...
cd web
call npx -y npm@11.16.0 run build
cd ..
echo Deploying to Firebase...
firebase deploy
pause
