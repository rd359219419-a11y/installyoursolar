#!/bin/bash
set -e
echo "====================================="
echo "Installing InstallYourSolar.com SaaS"
echo "====================================="
if ! command -v node >/dev/null 2>&1; then echo "Install Node.js 22.12+ from https://nodejs.org"; exit 1; fi
node -e "const [maj,min]=process.versions.node.split('.').map(Number); process.exit(maj>22 || (maj===22 && min>=12) ? 0 : 1)" || { echo "Node.js 22.12+ is required for the patched build toolchain."; exit 1; }
NPM_CMD="npx -y npm@11.16.0"
echo "Using npm 11.16.0 for install and build steps..."
cd web
$NPM_CMD install
$NPM_CMD run build
cd ../functions
$NPM_CMD install
cd ..
$NPM_CMD install -g firebase-tools
echo "Installation complete. Edit web/src/firebase.js and functions/index.js, then run firebase login and ./deploy.sh"
