# InstallYourSolar.com SaaS Platform

A modern solar installation lead-generation marketplace for homeowners, solar installers, and admins.

## Includes
- React/Vite frontend
- Homeowner solar quote request page
- Installer dashboard
- Client dashboard
- Admin dashboard
- AI-style lead matching score
- Stripe Checkout Cloud Function starter
- Firebase Hosting config
- Firestore rules
- Windows auto installer: install.bat
- Mac/Linux auto installer: install.sh
- Deploy scripts: deploy.bat and deploy.sh

## Quick Start

### Windows
Double-click `install.bat`, then run `deploy.bat`.

### Mac/Linux
```bash
chmod +x install.sh deploy.sh
./install.sh
./deploy.sh
```

## Firebase Setup
1. Create a Firebase project.
2. Enable Firestore.
3. Replace placeholder config in `web/src/firebase.js`.
4. Run `firebase login` and deploy. Firebase Functions are configured for the Node.js 22 runtime.

## Stripe Setup
Set the Stripe secret before deploying:
```bash
firebase functions:secrets:set STRIPE_SECRET_KEY
```

## Local Development
Requires Node.js 22.12+ and npm 11.16.0+.

```bash
cd web
npx -y npm@11.16.0 install
npx -y npm@11.16.0 run dev
```
