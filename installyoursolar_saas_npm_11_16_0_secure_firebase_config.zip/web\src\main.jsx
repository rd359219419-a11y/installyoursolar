import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Sun,
  ShieldCheck,
  Zap,
  BatteryCharging,
  Users,
  Star,
  DollarSign,
  LayoutDashboard,
  ClipboardList,
  MessageSquare,
  CreditCard,
  User,
  LogOut,
  Settings,
  SearchCheck,
  Home,
} from "lucide-react";
import "./styles.css";
import { db } from "./firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
const sampleLeads = [
  {
    name: "John Smith",
    location: "Auckland, NZ",
    type: "Residential Solar Installation",
    bill: "$220",
    roof: "Tiled Roof",
    status: "New",
    score: 96,
  },
  {
    name: "Sarah Johnson",
    location: "Hamilton, NZ",
    type: "Solar Battery Storage",
    bill: "$280",
    roof: "Metal Roof",
    status: "Contacted",
    score: 91,
  },
  {
    name: "Michael Brown",
    location: "Wellington, NZ",
    type: "EV Charger Installation",
    bill: "$150",
    roof: "Single Storey",
    status: "New",
    score: 87,
  },
];
function scoreLead(l) {
  let s = 50;
  if ((l.type || "").includes("Residential")) s += 20;
  if ((l.powerBill || "").includes("$") || Number(l.powerBill) > 150) s += 15;
  if ((l.roofType || "").toLowerCase().includes("tile")) s += 5;
  if ((l.location || "").length > 3) s += 10;
  return Math.min(s, 100);
}
function Nav({ page, setPage }) {
  let items = ["home", "client", "installer", "admin"];
  return (
    <header className="nav">
      <div className="brand" onClick={() => setPage("home")}>
        <Sun size={34} />
        <span>
          InstallYour<span>Solar.com</span>
        </span>
      </div>
      <nav>
        {items.map((i) => (
          <button
            key={i}
            className={page === i ? "active" : ""}
            onClick={() => setPage(i)}
          >
            {i === "home" ? "Home" : i[0].toUpperCase() + i.slice(1)}
          </button>
        ))}
      </nav>
      <div className="nav-actions">
        <button className="outline">Log In</button>
        <button className="green">Sign Up</button>
      </div>
    </header>
  );
}
function Stat({ icon, value, label }) {
  return (
    <div className="stat">
      {icon}
      <div>
        <strong>{value}</strong>
        <small>{label}</small>
      </div>
    </div>
  );
}
function Benefit({ icon, title, text }) {
  return (
    <div className="benefit">
      <div className="benefit-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}
function HomePage({ setPage }) {
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <h1>Find trusted solar installers near you</h1>
          <p>
            Compare quotes, connect with qualified solar installers, and start
            saving on your power bills with confidence.
          </p>
          <div className="hero-actions">
            <button className="green" onClick={() => setPage("client")}>
              Request a Solar Quote
            </button>
            <button className="outline">How It Works</button>
          </div>
          <div className="stats">
            <Stat icon={<Users />} value="5,000+" label="Verified Installers" />
            <Stat icon={<Zap />} value="20,000+" label="Solar Projects" />
            <Stat icon={<Star />} value="4.9" label="Average Rating" />
            <Stat icon={<ShieldCheck />} value="100%" label="Free to Use" />
          </div>
        </div>
        <div className="hero-image">
          <div className="sun-glow"></div>
          <div className="house-card">
            <div className="roof"></div>
            <div className="panels"></div>
            <div className="house"></div>
          </div>
        </div>
      </section>
      <section className="section-grid">
        <div className="panel large">
          <h2>Why homeowners choose InstallYourSolar.com</h2>
          <div className="benefits">
            <Benefit
              icon={<Sun />}
              title="Trusted Solar Installers"
              text="Connect with experienced local solar professionals who deliver quality work and peace of mind."
            />
            <Benefit
              icon={<DollarSign />}
              title="Save on Power Bills"
              text="Get custom solar solutions designed to reduce your energy costs and increase long-term savings."
            />
            <Benefit
              icon={<Zap />}
              title="Fast Quotes"
              text="Submit your project once and get responses from qualified installers near you."
            />
            <Benefit
              icon={<BatteryCharging />}
              title="Battery & EV Ready"
              text="Find experts for panels, battery storage, EV chargers, and off-grid solutions."
            />
          </div>
          <div className="cta-strip">
            <span>
              Request your solar quote today and take the first step toward
              energy freedom.
            </span>
            <button className="green" onClick={() => setPage("client")}>
              Get Started Now
            </button>
          </div>
        </div>
        <QuoteForm />
      </section>
      <Dashboards />
    </>
  );
}
function QuoteForm() {
  const [lead, setLead] = useState({ type: "Residential Solar Installation" });
  const [matchScore, setMatchScore] = useState(null);
  async function submitLead() {
    const scored = {
      ...lead,
      status: "New",
      aiScore: scoreLead(lead),
      createdAt: serverTimestamp(),
    };
    setMatchScore(scored.aiScore);
    try {
      await addDoc(collection(db, "leads"), scored);
      alert("Solar request submitted. AI match score: " + scored.aiScore + "%");
    } catch (e) {
      alert(
        "Demo mode: request captured locally. Add Firebase config to save leads.",
      );
    }
  }
  return (
    <div className="panel quote">
      <h2>Request a Solar Installation Quote</h2>
      <div className="form-grid">
        <input
          placeholder="Full name"
          onChange={(e) => setLead({ ...lead, name: e.target.value })}
        />
        <input
          placeholder="Property location"
          onChange={(e) => setLead({ ...lead, location: e.target.value })}
        />
        <input
          placeholder="Average monthly power bill"
          onChange={(e) => setLead({ ...lead, powerBill: e.target.value })}
        />
        <input
          placeholder="Roof / property type"
          onChange={(e) => setLead({ ...lead, roofType: e.target.value })}
        />
      </div>
      <select onChange={(e) => setLead({ ...lead, type: e.target.value })}>
        <option>Residential Solar Installation</option>
        <option>Commercial Solar Installation</option>
        <option>Solar Battery Storage</option>
        <option>EV Charger Installation</option>
        <option>Solar Panel Maintenance</option>
        <option>Off-Grid Solar System</option>
      </select>
      <textarea
        placeholder="Tell us about your solar project"
        onChange={(e) => setLead({ ...lead, details: e.target.value })}
      ></textarea>
      {matchScore && (
        <div className="match-score">AI job match score: {matchScore}%</div>
      )}
      <div className="form-actions">
        <button className="green" onClick={submitLead}>
          Submit Solar Request
        </button>
        <button className="outline">Pay Deposit Securely</button>
      </div>
    </div>
  );
}
function Sidebar({ title }) {
  let items = [
    [LayoutDashboard, "Dashboard"],
    [ClipboardList, "Leads"],
    [MessageSquare, "Messages"],
    [CreditCard, "Payments"],
    [User, "Profile"],
    [Settings, "Settings"],
    [LogOut, "Log Out"],
  ];
  return (
    <aside className="sidebar">
      <h3>
        <Sun size={18} /> {title}
      </h3>
      {items.map(([Icon, label]) => (
        <span key={label}>
          <Icon size={15} /> {label}
        </span>
      ))}
    </aside>
  );
}
function InstallerDashboard({ compact }) {
  return (
    <div className={compact ? "dashboard-card" : "dashboard-page"}>
      <Sidebar title="InstallYourSolar.com" />
      <main>
        <h2>Installer Dashboard</h2>
        {sampleLeads.map((lead) => (
          <div className="lead-row" key={lead.name}>
            <div>
              <strong>{lead.type}</strong>
              <small>{lead.location}</small>
            </div>
            <span>{lead.bill}</span>
            <span>{lead.roof}</span>
            <span>{lead.score}% match</span>
            <button className="green small">View Details</button>
          </div>
        ))}
      </main>
    </div>
  );
}
function StatBox({ label, value }) {
  return (
    <div className="stat-box">
      <strong>{value}</strong>
      <small>{label}</small>
    </div>
  );
}
function AdminDashboard({ compact }) {
  return (
    <div className={compact ? "dashboard-card" : "dashboard-page"}>
      <Sidebar title="InstallYourSolar.com" />
      <main>
        <h2>Admin Dashboard</h2>
        <div className="admin-stats">
          <StatBox label="Total Leads" value="2,350" />
          <StatBox label="Active Installers" value="520" />
          <StatBox label="Projects Completed" value="1,890" />
          <StatBox label="Total Revenue" value="$245,680" />
        </div>
        <div className="table">
          {sampleLeads.map((lead) => (
            <div className="table-row" key={lead.name}>
              <span>{lead.name}</span>
              <span>{lead.location}</span>
              <span>{lead.type}</span>
              <span className="green-text">{lead.status}</span>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
function ClientDashboard({ compact }) {
  return (
    <div className={compact ? "dashboard-card" : "dashboard-page"}>
      <Sidebar title="InstallYourSolar.com" />
      <main>
        <h2>Client Dashboard</h2>
        <div className="client-job">
          <strong>Residential Solar Installation</strong>
          <span className="badge">In Progress</span>
          <p>3 quotes received - Last update: 2 hours ago</p>
        </div>
        <h3>Recommended Installers</h3>
        <div className="installer-cards">
          {["Solar Solutions Pro", "Bright Energy", "Sunshine Solar"].map(
            (name) => (
              <div className="mini-card" key={name}>
                <div className="avatar"></div>
                <strong>{name}</strong>
                <small>4.9 stars</small>
                <button className="green small">View Profile</button>
              </div>
            ),
          )}
        </div>
      </main>
    </div>
  );
}
function Dashboards() {
  return (
    <section className="dashboards">
      <InstallerDashboard compact />
      <AdminDashboard compact />
      <ClientDashboard compact />
    </section>
  );
}
function ClientPage() {
  return (
    <div className="page">
      <QuoteForm />
      <ClientDashboard />
    </div>
  );
}
function InstallerPage() {
  return (
    <div className="page">
      <div className="panel">
        <h1>Installer Leads</h1>
        <p>
          AI-ranked solar opportunities based on location, project type, roof
          details, budget and urgency.
        </p>
        <div className="ai-box">
          <SearchCheck /> Smart matching enabled: priority leads are ranked
          automatically.
        </div>
      </div>
      <InstallerDashboard />
    </div>
  );
}
function AdminPage() {
  return (
    <div className="page">
      <AdminDashboard />
    </div>
  );
}
function App() {
  const [page, setPage] = useState("home");
  return (
    <>
      <Nav page={page} setPage={setPage} />
      {page === "home" && <HomePage setPage={setPage} />}{" "}
      {page === "client" && <ClientPage />}{" "}
      {page === "installer" && <InstallerPage />}{" "}
      {page === "admin" && <AdminPage />}
    </>
  );
}
const rootElement = document.getElementById("root");
const root = window.__installYourSolarRoot || createRoot(rootElement);
window.__installYourSolarRoot = root;
root.render(<App />);
