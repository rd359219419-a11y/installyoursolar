import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDUX1kZgbuN-tC8J93Hk_T8I_MZrFWHv10",
  authDomain: "installyoursolar.firebaseapp.com",
  projectId: "installyoursolar",
  storageBucket: "installyoursolar.firebasestorage.app",
  messagingSenderId: "625262720170",
  appId: "1:625262720170:web:e7c9f8309feb4146050cd3",
  measurementId: "G-L1Y3SJCFR6",
};
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
