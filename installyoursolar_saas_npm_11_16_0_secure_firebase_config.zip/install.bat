@echo off
echo =====================================
echo Installing InstallYourSolar.com SaaS
echo =====================================
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo Node.js is not installed. Install Node.js 22.12+ from https://nodejs.org
  pause
  exit /b
)
node -e "const [maj,min]=process.versions.node.split('.').map(Number); process.exit(maj>22 || (maj===22 && min>=12) ? 0 : 1)"
if %errorlevel% neq 0 (
  echo Node.js 22.12+ is required for the patched build toolchain.
  pause
  exit /b
)
set "NPM_CMD=npx -y npm@11.16.0"
echo Using npm 11.16.0 for install and build steps...
echo Installing frontend dependencies...
cd web
call %NPM_CMD% install
call %NPM_CMD% run build
cd ..
echo Installing Firebase Functions dependencies...
cd functions
call %NPM_CMD% install
cd ..
echo Installing Firebase CLI globally...
call %NPM_CMD% install -g firebase-tools
echo.
echo Installation complete.
echo Next: edit web\src\firebase.js and functions\index.js, then run firebase login and deploy.bat
pause
