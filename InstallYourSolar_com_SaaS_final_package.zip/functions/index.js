const functions = require("firebase-functions");
const admin = require("firebase-admin");
const dotenv = require("dotenv");

dotenv.config();
admin.initializeApp();

const stripeSecret =
  process.env.STRIPE_SECRET ||
  (functions.config().stripe && functions.config().stripe.secret) ||
  "YOUR_STRIPE_SECRET_KEY";

const stripe = require("stripe")(stripeSecret);

exports.createCheckout = functions.https.onRequest(async (req, res) => {
  try {
    if (req.method !== "POST") {
      return res.status(405).send("Method Not Allowed");
    }

    const amount = req.body && req.body.amount ? Number(req.body.amount) : 50000;

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [{
        price_data: {
          currency: "nzd",
          product_data: {
            name: "Solar Installation Deposit"
          },
          unit_amount: amount
        },
        quantity: 1
      }],
      mode: "payment",
      success_url: "https://yourdomain.com/success",
      cancel_url: "https://yourdomain.com/cancel"
    });

    res.json({ url: session.url });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});