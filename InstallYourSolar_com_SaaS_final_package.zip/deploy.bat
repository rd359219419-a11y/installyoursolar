@echo off
echo Building InstallYourSolar.com...
cd web
call npm run build
cd ..

echo Deploying to Firebase...
firebase deploy

pause