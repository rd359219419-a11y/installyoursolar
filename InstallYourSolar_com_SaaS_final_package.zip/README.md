# InstallYourSolar.com SaaS Package

A deployable solar lead-generation marketplace for homeowners and solar installers.

## Included

- Homeowner landing page
- Solar quote request form
- Full-width client area demo image
- Full-width installer area demo image
- Installer dashboard
- AI-style lead matching score
- Hidden admin dashboard
- Dedicated admin login page
- Firebase Firestore integration placeholders
- Stripe Checkout starter function
- Windows installer: `install.bat`
- Mac/Linux installer: `install.sh`
- Windows deploy script: `deploy.bat`
- Mac/Linux deploy script: `deploy.sh`

## Admin Login

The admin dashboard is not shown in the public navigation.

Admin login URL:

`/admin-login`

Default demo login:

- Username: `admin`
- Password: `solaradmin123`

Important: before going live, change these values in:

`web/src/pages/AdminLogin.jsx`

For a true production system, replace this simple local login with Firebase Auth custom claims.

## Setup

### 1. Install

Windows:

Double-click:

`install.bat`

Mac/Linux:

```bash
chmod +x install.sh
./install.sh
```

### 2. Firebase

Create a Firebase project, then replace the config in:

`web/src/firebase.js`

### 3. Stripe

Add your Stripe secret key in:

`functions/.env`

Use `.env.example` as the template.

### 4. Deploy

Windows:

`deploy.bat`

Mac/Linux:

```bash
chmod +x deploy.sh
./deploy.sh
```

## Notes

This is a SaaS starter package. It includes real frontend structure and Firebase-ready backend placeholders. Before production launch, upgrade security rules, admin auth, payments, and user verification.