import { useState } from "react";
import { useNavigate } from "react-router-dom";

const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "solaradmin123";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const login = e => {
    e.preventDefault();

    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      localStorage.setItem("installYourSolarAdmin", "true");
      navigate("/admin");
      return;
    }

    setError("Incorrect admin username or password.");
  };

  return (
    <div className="admin-login-page">
      <form className="card admin-login-card" onSubmit={login}>
        <h1>Admin Login</h1>
        <p>Private access for InstallYourSolar.com administrators.</p>

        {error && <div className="error">{error}</div>}

        <input
          placeholder="Admin username"
          value={username}
          onChange={e => setUsername(e.target.value)}
        />

        <input
          placeholder="Admin password"
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />

        <button type="submit">Login to Admin Dashboard</button>

        <p style={{ fontSize: "13px", color: "#94a3b8" }}>
          Default demo login: admin / solaradmin123. Change this before going live.
        </p>
      </form>
    </div>
  );
}