export { default } from "./Installer";
