import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { db } from "../firebase";
import { collection, onSnapshot } from "firebase/firestore";

export default function Admin() {
  const [jobs, setJobs] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "jobs"), snap => {
      setJobs(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => unsub();
  }, []);

  const logout = () => {
    localStorage.removeItem("installYourSolarAdmin");
    navigate("/admin-login");
  };

  const openJobs = jobs.filter(j => (j.status || "open") === "open").length;
  const assignedJobs = jobs.filter(j => j.status === "assigned").length;
  const batteryLeads = jobs.filter(j => j.type?.includes("Battery")).length;

  return (
    <section className="section">
      <div className="admin-toolbar">
        <h1 className="section-title">InstallYourSolar.com Admin Dashboard</h1>
        <button className="small-btn" onClick={logout}>Logout</button>
      </div>

      <div className="grid-2">
        <div className="card">
          <h3>Total Solar Leads</h3>
          <p style={{ fontSize: "42px", margin: 0 }}>{jobs.length}</p>
        </div>

        <div className="card">
          <h3>Open Leads</h3>
          <p style={{ fontSize: "42px", margin: 0 }}>{openJobs}</p>
        </div>

        <div className="card">
          <h3>Assigned Leads</h3>
          <p style={{ fontSize: "42px", margin: 0 }}>{assignedJobs}</p>
        </div>

        <div className="card">
          <h3>Battery Leads</h3>
          <p style={{ fontSize: "42px", margin: 0 }}>{batteryLeads}</p>
        </div>
      </div>

      <div className="card" style={{ marginTop: "24px" }}>
        <h2>Recent Leads</h2>
        {jobs.map(j => (
          <div key={j.id} style={{ borderTop: "1px solid rgba(255,255,255,0.1)", padding: "14px 0" }}>
            <b>{j.type || "Solar Lead"}</b>
            <p>Location: {j.location || "Not provided"}</p>
            <p>Status: {j.status || "open"}</p>
          </div>
        ))}
      </div>
    </section>
  );
}