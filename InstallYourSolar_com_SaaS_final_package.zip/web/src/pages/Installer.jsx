import { useEffect, useState } from "react";
import { db } from "../firebase";
import { collection, onSnapshot, updateDoc, doc } from "firebase/firestore";
import heroImage from "../assets/install-your-solar-hero.png";

function scoreLead(job) {
  let score = 40;
  if (job.powerBill) score += 20;
  if (job.roofType) score += 15;
  if (job.type?.includes("Battery") || job.type?.includes("Commercial")) score += 15;
  if (job.details && job.details.length > 40) score += 10;
  return Math.min(score, 100);
}

export default function Installer() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "jobs"), snap => {
      setJobs(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => unsub();
  }, []);

  const accept = async id => {
    await updateDoc(doc(db, "jobs", id), {
      status: "assigned"
    });
  };

  return (
    <div>
      <section className="dashboard-hero card">
        <img src={heroImage} alt="Installer dashboard" />
        <div>
          <h1>Installer Dashboard</h1>
          <p>
            View solar leads, see AI-style matching scores, accept projects,
            and grow your solar installation business.
          </p>
        </div>
      </section>

      <section className="section">
        <h2 className="section-title">Available Solar Leads</h2>

        {jobs.map(j => (
          <div key={j.id} className="card">
            <h3>{j.type || "Solar Installation Lead"}</h3>
            <p><b>Location:</b> {j.location}</p>
            <p><b>Monthly Power Bill:</b> {j.powerBill}</p>
            <p><b>Roof / Property Type:</b> {j.roofType}</p>
            <p><b>AI Match Score:</b> {scoreLead(j)}%</p>
            <p>{j.details}</p>
            <p><b>Status:</b> {j.status || "open"}</p>
            <button onClick={() => accept(j.id)}>Accept Solar Lead</button>
          </div>
        ))}
      </section>
    </div>
  );
}