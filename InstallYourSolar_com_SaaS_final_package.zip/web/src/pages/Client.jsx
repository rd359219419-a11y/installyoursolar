import { useState } from "react";
import { db } from "../firebase";
import { addDoc, collection } from "firebase/firestore";
import { createCheckout } from "../api";
import heroImage from "../assets/install-your-solar-hero.png";

export default function Client() {
  const [job, setJob] = useState({
    type: "Residential Solar Installation"
  });

  const submit = async () => {
    await addDoc(collection(db, "jobs"), {
      ...job,
      status: "open",
      createdAt: new Date()
    });
    alert("Solar quote request submitted");
  };

  const pay = async () => {
    const { url } = await createCheckout();
    if (url) window.location.href = url;
  };

  return (
    <div>
      <section className="hero">
        <div className="hero-copy">
          <h1>Install solar with confidence.</h1>
          <p>
            InstallYourSolar.com connects homeowners and businesses with trusted
            solar installers for panels, batteries, EV chargers, maintenance,
            and off-grid power systems.
          </p>

          <div className="hero-actions">
            <button
              className="primary-btn"
              onClick={() =>
                document.getElementById("quoteForm").scrollIntoView({ behavior: "smooth" })
              }
            >
              Get a Free Solar Quote
            </button>

            <button
              className="secondary-btn"
              onClick={() =>
                document.getElementById("whyJoin").scrollIntoView({ behavior: "smooth" })
              }
            >
              Why Join?
            </button>
          </div>
        </div>

        <div className="hero-image-wrap">
          <img
            className="hero-image"
            src={heroImage}
            alt="InstallYourSolar.com SaaS platform overview"
          />
        </div>
      </section>

      <section className="trust-bar">
        <div className="stat-card"><strong>Fast</strong>Solar quote requests in minutes.</div>
        <div className="stat-card"><strong>Local</strong>Get matched with nearby installers.</div>
        <div className="stat-card"><strong>Secure</strong>Deposit and checkout-ready system.</div>
        <div className="stat-card"><strong>Smart</strong>AI-style installer matching scores.</div>
      </section>

      <section className="preview-section">
        <div className="preview-copy">
          <h2>Client Area Preview</h2>
          <p>
            Homeowners can request solar quotes, compare installer responses,
            pay deposits, and manage their solar project from one simple dashboard.
          </p>
        </div>

        <img
          className="full-width-demo"
          src={heroImage}
          alt="InstallYourSolar.com client area demo"
        />
      </section>

      <section className="preview-section">
        <div className="preview-copy">
          <h2>Installer Area Preview</h2>
          <p>
            Solar installers can view matched leads, see project details,
            check AI-style lead scores, accept jobs, and grow their business.
          </p>
        </div>

        <img
          className="full-width-demo"
          src={heroImage}
          alt="InstallYourSolar.com installer area demo"
        />
      </section>

      <section id="whyJoin" className="section">
        <h2 className="section-title">Why clients choose InstallYourSolar.com</h2>

        <div className="grid-2">
          <div className="card">
            <h3>☀️ Find trusted solar professionals</h3>
            <p>
              Reach qualified installers who can help with rooftop solar,
              battery storage, EV charging, and energy upgrades.
            </p>
          </div>

          <div className="card">
            <h3>💸 Compare value before you commit</h3>
            <p>
              Submit one request and compare installer responses, system options,
              estimated savings, and project timelines.
            </p>
          </div>

          <div className="card">
            <h3>🔋 Future-ready energy setup</h3>
            <p>
              Ask for solar panels, batteries, smart energy monitoring, EV chargers,
              and off-grid solutions in one simple platform.
            </p>
          </div>

          <div className="card">
            <h3>⚡ Save time and reduce hassle</h3>
            <p>
              No chasing multiple companies. Your project details go straight to
              installers who match your location and project type.
            </p>
          </div>
        </div>
      </section>

      <section id="quoteForm" className="section">
        <div className="card">
          <h2 className="section-title">Request a Solar Installation Quote</h2>

          <div className="form-grid">
            <input placeholder="Full name" onChange={e => setJob({ ...job, name: e.target.value })} />
            <input placeholder="Property location" onChange={e => setJob({ ...job, location: e.target.value })} />
            <input placeholder="Average monthly power bill" onChange={e => setJob({ ...job, powerBill: e.target.value })} />
            <input placeholder="Roof type / property type" onChange={e => setJob({ ...job, roofType: e.target.value })} />

            <select onChange={e => setJob({ ...job, type: e.target.value })}>
              <option>Residential Solar Installation</option>
              <option>Commercial Solar Installation</option>
              <option>Solar Battery Storage</option>
              <option>EV Charger Installation</option>
              <option>Solar Panel Maintenance</option>
              <option>Off-Grid Solar System</option>
            </select>

            <input placeholder="Preferred contact number" onChange={e => setJob({ ...job, phone: e.target.value })} />

            <textarea
              className="full"
              placeholder="Tell us about your solar project"
              onChange={e => setJob({ ...job, details: e.target.value })}
            />
          </div>

          <button onClick={submit}>Submit Solar Request</button>
          <button onClick={pay}>Pay Deposit</button>
        </div>
      </section>
    </div>
  );
}