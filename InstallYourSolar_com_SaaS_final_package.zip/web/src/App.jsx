import { Routes, Route, Link } from "react-router-dom";
import Client from "./pages/Client";
import Installer from "./pages/Installer";
import Admin from "./pages/Admin";
import AdminLogin from "./pages/AdminLogin";
import "./styles.css";

function ProtectedAdmin() {
  const isAdminLoggedIn = localStorage.getItem("installYourSolarAdmin") === "true";
  return isAdminLoggedIn ? <Admin /> : <AdminLogin />;
}

export default function App() {
  return (
    <div>
      <nav className="nav">
        <h2>☀️ InstallYourSolar.com</h2>

        <div>
          <Link to="/">Homeowners</Link>
          <Link to="/installer">Installers</Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Client />} />
        <Route path="/installer" element={<Installer />} />
        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/admin" element={<ProtectedAdmin />} />
      </Routes>
    </div>
  );
}