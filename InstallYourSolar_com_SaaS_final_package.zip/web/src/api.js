export async function createCheckout(amount = 50000) {
  const response = await fetch("/createCheckout", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ amount })
  });

  return response.json();
}