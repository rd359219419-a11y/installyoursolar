#!/bin/bash
set -e

echo "Building InstallYourSolar.com..."
cd web
npm run build
cd ..

echo "Deploying to Firebase..."
firebase deploy