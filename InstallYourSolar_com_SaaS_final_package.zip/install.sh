#!/bin/bash
set -e

echo "=========================================="
echo "InstallYourSolar.com SaaS Installer"
echo "=========================================="

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Please install Node.js 18+ first."
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "npm is not installed. Please install Node.js/npm first."
  exit 1
fi

echo "Installing web dependencies..."
cd web
npm install

echo "Building web app..."
npm run build

cd ..

echo "Installing Firebase Functions dependencies..."
cd functions
npm install

cd ..

echo ""
echo "Installation complete."
echo ""
echo "Admin login default:"
echo "Username: admin"
echo "Password: solaradmin123"
echo ""
echo "IMPORTANT: Change admin username/password in web/src/pages/AdminLogin.jsx before going live."
echo ""
echo "Next steps:"
echo "1. Edit web/src/firebase.js with your Firebase config."
echo "2. Edit functions/.env or Firebase functions config with your Stripe secret."
echo "3. Run firebase login."
echo "4. Run ./deploy.sh"