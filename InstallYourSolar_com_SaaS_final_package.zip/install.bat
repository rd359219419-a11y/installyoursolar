@echo off
echo ==========================================
echo InstallYourSolar.com SaaS Installer
echo ==========================================

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo Node.js is not installed. Please install Node.js 18+ first.
  pause
  exit /b
)

where npm >nul 2>nul
if %errorlevel% neq 0 (
  echo npm is not installed. Please install Node.js/npm first.
  pause
  exit /b
)

echo Installing web dependencies...
cd web
call npm install

echo Building web app...
call npm run build

cd ..

echo Installing Firebase Functions dependencies...
cd functions
call npm install

cd ..

echo.
echo Installation complete.
echo.
echo Admin login default:
echo Username: admin
echo Password: solaradmin123
echo.
echo IMPORTANT: Change admin username/password in web\src\pages\AdminLogin.jsx before going live.
echo.
echo Next steps:
echo 1. Edit web\src\firebase.js with your Firebase config.
echo 2. Edit functions\.env or Firebase functions config with your Stripe secret.
echo 3. Run firebase login.
echo 4. Run deploy.bat.
pause